# XML Generator
Used to generate updates to tables in the siena database.

Generates XML that can be manually importer, or imported using the static data importer.
